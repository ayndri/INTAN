<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccountingEntriesController extends Controller
{
    //
}
